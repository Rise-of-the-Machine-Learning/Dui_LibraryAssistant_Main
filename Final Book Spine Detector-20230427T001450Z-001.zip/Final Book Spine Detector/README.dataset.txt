# Book Spine Detector > 2023-04-25 2:31pm
https://universe.roboflow.com/bookdetection-lgtpa/book-spine-detector

Provided by a Roboflow user
License: CC BY 4.0

